###Member List

This contains a report/list of library members. In this menu there is a facility to sort and print. In addition, there are also filter amenities, ie based on:
- Membership Type, 
- Member ID/Member Name, 
- Gender, 
- Address, 
- “Register Date From," 
- “Register Date Until.”

This feature also provides the facility to create a spreadsheet file download. Files can be obtained by clicking "Export to spreadsheet format".
