#### Current Stoctake
<hr>
This menu is the main menu for doing a stock-take. It is used to restore the status of library collections that are considered lost by the system, In this menu, item id (barcode number) is the main item reference to change the status of the items that are considered lost to existing (there), Do this by entering the barcode number in the field Item Code. This menu will work when the Initialize process is completed.
