####Master File / Label
<hr>
To provide specific information about the bibliographic item. labels can be defined in the Master File menu. By default Senayan has three labels: 
- New Title, 
- Favorite Title, and 
- Multimedia.
