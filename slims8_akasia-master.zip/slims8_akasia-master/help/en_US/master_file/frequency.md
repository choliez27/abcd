####Master File / Frequency
<hr>
The language used by the document. Eg: Indonesian, English, French, Javanese etc..
