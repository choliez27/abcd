####Master File / Item status
<hr>
Contains the status of the item (Repair, On Loan, Reserved). Each Item Status category contains the Item Status Code , Item Status Name and Rules. There are two options in Rules:
- No Loan Transaction (items can not be borrowed, eg digital collections) and 
- Skipped by Take Stock (not contained in the process of the Stock Take)
