#### Item List
<hr>
This menu is used to view items in the Senayan database. The information contained in this menu are: Item Code, Title, Type, Location, Class, and Last Update. This menu can also be used to edit and delete items. 