####Import Data

This menu is used to retrieve member data from outside applications to put into Senayan applications. The data format of the import is .csv.
