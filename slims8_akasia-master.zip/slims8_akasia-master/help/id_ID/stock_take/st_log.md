## Catatan inventarisasi
<hr>
Fungsi menu ini adalah untuk mengetahui rekaman (Log) saat melakukan proses stock take
