####Inventarisasi Aktif (Current Stoctake)
<hr>
Menu itu adalah menu utama untuk melakukan stock take. Menu ini digunakan untuk mengembalikan status koleksi perpustakaan yang dianggap hilang oleh sistem, ke status exist (koleksi dinyatakan ada).
Pada menu ini, item id (nomor barcode) koleksi menjadi acuan utama untuk mengubah status koleksi yang dianggap hilang menjadi exist (ada),
Caranya dengan memasukan nomor barcode koleksi tersebut pada kolom Item Code.
Menu ini akan berfungsi apabila telah dilakukan proses Initialize. 
