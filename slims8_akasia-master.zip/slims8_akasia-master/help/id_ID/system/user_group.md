### Kelompok Pengguna
<hr>
Merupakan fasilitas untuk mendefinisikan Groups dari User. Dalam User Groups ini anda bisa membuat pengelompokan User-user system anda serta memberikan hak baca (Read) atau tulis (Write) pada modul-modul SLiMS. Setiap User pada SLiMS bisa bergabung ke lebih dari satu grup.
