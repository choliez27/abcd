### Pengguna dan Pustakawan Sistem
<hr>
Merupakan fasilitas untuk menentukan user yang dapat mengakses sistem sesuai dengak haknya masing-masing. User ini nantinya dapat melakukan login sesuai dengan username dan passwordnya masing-masing. Dalam menu ini terdapat beberapa fasilitas: Add New User (menambah user), Users List (melihat daftar user), Search (mencari user), Edit dan delete user. Untuk menambah user baru, klik Add New User, kemudian isikan Login Username, Real Name, Groups, Password. Selain itu, adapula fasilitas untuk mengunggah foto pustakawan dan alamat media sosial pustakawan.

Profil dari masing-masing staf yang diset dengan tipe "Pustakawan" akan ditampilkan pada halaman OPAC.
