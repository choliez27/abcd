####P2P Service
<hr>
Fitur ini adalah untuk berbagi data bibliografi antar pengguna SLiMS. P2P Service memanfaatkan fasilitas xml yang telah ada di SLIMS untuk berbagi koleksi bibligrafi.

####Cara Penggunaan
<hr>
Untuk penggunaan P2P Service ini, cukup dengan klik p2p service, isikan kata kunci dan pilih lokasi/url/perpustakaan yang dituju untuk pencarian. Jika sistem menemukan koleksi yang dicari, maka akan ditampilkan hasil pencarian.
Pencarian pada P2P Service ini dapat menggunakan pencarian spesifik model Boolean. 
> Sebagai contoh 
> > isbn=0-596-00108-8 AND title=bazaar. 

Selain ISBN dan Title, pencarian detail dapat juga menggunakan author, GMD dan subject. 
