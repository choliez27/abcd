### Terbitan berseri
<hr>
Modul ini memfasilitasi anda untuk mengelola terbitan berkala dengan model kardex.
Pertama kali anda harus mencari terbitan berseri yang diinginkan, membuat kardex pada modul ini, kemudian mengisinya sesuai. Dokumen yang muncul dalam modul ini merupakan dokumen yang diisikan pada modul Bibliografi, serta ditentukan periode terbitannya. Kardex berisi definisi tentang:
- Permulaan langganan
- Eksemplar yang diharapkan selama langganan
- Nama periode
- Catatan
- GMD
