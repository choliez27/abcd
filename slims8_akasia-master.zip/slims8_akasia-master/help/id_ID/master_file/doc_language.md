####Master File / Bahasa Dokumen
<hr>
Gunakan fitur ini untuk mengisi daftar bahasa koleksi/dokumen yang tersedia di perpustakaan.
Misal: Bahasa Indonesia, Bahasa Inggris, Bahasa Perancis, Bahasa Jawa dll.
