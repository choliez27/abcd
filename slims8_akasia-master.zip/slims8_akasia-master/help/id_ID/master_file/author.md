####Master File / Pengarang
<hr>
Gunakan fitur ini untuk mengentri daftar nama pengarang dan jenis pengarang (pribadi atau kelompok)
