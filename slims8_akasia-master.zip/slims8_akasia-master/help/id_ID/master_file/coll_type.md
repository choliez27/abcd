####Master File / Tipe Koleksi
<hr>
Gunakan fitur ini untuk mengisi tipe koleksi yang dimiliki perpustakaan,
Contoh: Textbook, Reference, Audio Visual, Skripsi, Thesis, Laporan
