###Mulai Transaksi

Untuk melakukan transaksi, masukkan Member ID (ID anggota). Setelah Member ID dimasukkan, maka akan muncul informasi anggota, yaitu: 
- Member Name (nama anggota), 
- Member E-Mail (email anggota), 
- Register Date (tanggal mendaftar), 
- Member ID (ID anggota), 
- Member Type (jenis keanggotaan), 
- Expire Date (tanggal akhir keanggotaan) 
- foto anggota. 

Dibawahnya terdapat tab Loans (untuk melakukan transaksi peminjaman), Current Loans (daftar peminjaman terkini), Reserve (untuk kebutuhan pemesanan literatur), Fines (denda), Loan History (sejarah peminjaman yang dilakukan oleh anggota). Dalam Current Loans juga terdapat fasilitas untuk mengembalikan (Return) dan memperpanjang (Extend) peminjaman.
