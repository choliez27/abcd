### Daftar pengunjung
<hr>
Laporan ini berisi daftar nama anggota atau non anggota perpustakaan yang berkunjung ke perpustakaan. Informasi pada laporan ini berisi Member ID, Member Name, Member Type, Institution dan Visit date.
Penjelasan selanjutnya mengenai fitur presensi, silakan lihat pada bagian presensi.