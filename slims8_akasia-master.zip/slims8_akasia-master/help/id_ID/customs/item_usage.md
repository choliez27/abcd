###Statistik Penggunaan Koleksi  

Merupakan laporan yang menginformasikan item, title dan berapa kali item tersebut dipinjam pada setiap bulannya. Item usage ini dapat pula ditapis dengan:
- Title/ISBN, 
- Item code, atau 
- Year.
